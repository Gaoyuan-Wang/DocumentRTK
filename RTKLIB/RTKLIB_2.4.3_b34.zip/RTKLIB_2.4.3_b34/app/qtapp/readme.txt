readme.txt
2020/12/14

Files in this QT APP project directory are moved from the 
previous release rtklib/app/. However, these are not maintained
or updated. The APs may not be built with the latest release
RTKLIB codes.

