cp rtkplot_qt ../../../RTKLIB_bin/bin
