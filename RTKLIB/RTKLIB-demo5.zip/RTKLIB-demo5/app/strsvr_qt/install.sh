cp release\strsvr_qt ../../../RTKLIB_bin/bin
