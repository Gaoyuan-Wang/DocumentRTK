function utest_eph
% matlab script for rtklib unit test
% after executing utest for rtklib, execute it
% need gt 0.6.4

testpeph1
testpeph2
testgloeph

